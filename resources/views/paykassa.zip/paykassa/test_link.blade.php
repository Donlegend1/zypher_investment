<!DOCTYPE html>
<html>
<head>
    <title>Test Payment Link</title>
</head>
<body>
    <h1>Test Mode Link</h1>
    <p><a href="{{ $testLink }}" target="_blank">Open link</a></p>
</body>
</html>