<!DOCTYPE html>
<html>
<head>
    <title>Payment Address</title>
</head>
<body>
    <h1>Payment Address</h1>
    <p>{!! $message !!}</p>
    <p>{!! $qrCodeImage !!}</p>
</body>
</html>